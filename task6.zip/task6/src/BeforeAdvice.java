
public interface BeforeAdvice extends Advice {
	
}
