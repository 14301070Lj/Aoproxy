
public class FooImpl implements FooInterface {

	public void printFoo() {
		System.out.println("in FooImpl.printFoo!!!");
		// TODO Auto-generated method stub
	}

	public void dummyFoo() {
		 System.out.println("in FooImpl.dummyFoo!!!");
		// TODO Auto-generated method stub
		
	}

}
