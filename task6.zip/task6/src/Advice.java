
public interface Advice {

	void setTargetObject(Object proxyObject);

}
